Rethoughted Spawn Eggs
Version - 1.1
Made by CatFromNet

Project links:
• Modrinth — https://modrinth.com/resourcepack/rethoughted-spawn-eggs
• CurseForge — https://www.curseforge.com/minecraft/texture-packs/rethoughted-spawn-eggs

Feedback and socials:
• Creator links — https://linktr.ee/catfromnet
• Discord server — https://discord.gg/q29y59SWEu
